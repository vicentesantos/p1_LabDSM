const db = require("../banco")
const Cadastro = db.sequelize.define('cadastro',{
    nome:{
        type: db.Sequelize.STRING
    },
    telefone:{
        type: db.Sequelize.INTEGER
    },
    origem:{
        type: db.Sequelize.STRING
    },
    data_contato:{
        type: db.Sequelize.DATE
    },
    observacao:{
        type: db.Sequelize.TEXT
    }
})
//Cadastro.sync({force:true})
module.exports = Cadastro